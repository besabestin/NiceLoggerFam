//
//  NiceLoggerFam.h
//  NiceLoggerFam
//
//  Created by iOS Developer on 15.05.18.
//  Copyright © 2018 iOS Developer. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NiceLoggerFam.
FOUNDATION_EXPORT double NiceLoggerFamVersionNumber;

//! Project version string for NiceLoggerFam.
FOUNDATION_EXPORT const unsigned char NiceLoggerFamVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NiceLoggerFam/PublicHeader.h>


